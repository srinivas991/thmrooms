// Monitorr //

- This directory is the Monitorr application data directory. (/assets/data/). 
- This directory includes the VERY important "datadir.json" file which defines where on the server your personalized data directory is. 
- The datadir.json file is generated during the registration process, UNLESS using docker in which this file was created when the image was mounted. 