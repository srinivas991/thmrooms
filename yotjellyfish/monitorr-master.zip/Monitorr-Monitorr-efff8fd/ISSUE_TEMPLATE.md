## Your environment:

- **Operating system**: Windows 10P x65 build: 1709

- **Webserver**:       NGINX v. 3.8

- **PHP Version**:      7.2.1 x64 NTS

- **Monitorr Version**:   0.21m  (in the footer of the Monitorr UI)

## Describe your issue:

I have read the t-shooting Wiki at: https://github.com/Monitorr/Monitorr/wiki/06-Troubleshooting
